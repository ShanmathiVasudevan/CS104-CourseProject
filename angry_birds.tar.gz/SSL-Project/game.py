import pygame
import numpy as np
import random
import sys
import player
import menu
import obstacle
import help

'''code for the playing part of the game'''

def load_sound(name): #function to load sound; if the mixer is unavailable it does nothing instead of throwing error
    class NoneSound:
        def play(self): #if the code asks to play the sound but the mixer is unavailable, it does nothing
            pass
    if not pygame.mixer.get_init():
        return NoneSound()
    fullname = "sounds/" + name
    sound = pygame.mixer.Sound(fullname)
    return sound

def render_text(surface,font,text,colour,position): #function to render text on the surface
    text_surface = font.render(text,True,colour)
    text_rect = text_surface.get_rect(center = position)
    surface.blit(text_surface,text_rect)

def game(p1,p2,level_no):
    HEIGHT = 1280
    WIDTH = 600
    player1_name = p1
    player2_name = p2
    screen = pygame.display.set_mode((HEIGHT, WIDTH), pygame.SCALED)
    font = pygame.font.Font("fonts/FeastOfFleshBb-AVm.ttf",WIDTH//15)

    '''setting up the background based on the level number'''
    if level_no == 1:
        background_image = pygame.image.load('images/background_1.png').convert()
    elif level_no == 2:
        background_image = pygame.image.load('images/background_1.png').convert()
    elif level_no == 3:
        background_image = pygame.image.load('images/background_3.png').convert()
    background_image = pygame.transform.scale(background_image,(HEIGHT,WIDTH))
    background = pygame.Surface(screen.get_size())
    background = background.convert()
    background.blit(background_image,(0,0))
    screen.blit(background, (0, 0))
    
    '''setting up the player objects'''
    player1 = player.Player(0,level_no)
    player2 = player.Player(HEIGHT,level_no)

    '''setting up the obstacle'''
    if level_no != 1:
        obstacle1 = obstacle.Obstacle(level_no)
        obstacle1.rect.center = (HEIGHT/2,100)
        obstacle1.add(player1.all_sprites, player2.all_sprites)

    clock = pygame.time.Clock()
    winner = None
    going = True

    '''randomly pick the 1st player'''
    x = random.randint(1,2)
    if x == 1:
        player1.state = True
    else:
        player2.state = True
    print(x)
    button = load_sound("button_clicked.wav")
    info_button = pygame.image.load("images/info_button.png")
    '''game loop'''
    while going:
        clock.tick(60)
        '''checks if the player has no birds left, and if so, regenerates them'''
        player1.regenerate()
        player2.regenerate()
        
        '''checks for mouse clicks and keyboard inputs (escape key)'''
        for event in pygame.event.get():
            #print(event.type)
            if event.type == pygame.QUIT:
                going = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                going = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if HEIGHT - 45 < mouse_pos[0] < HEIGHT-5 and 5 < mouse_pos[1] < 45: # help button
                    button.play()
                    exit = True
                    screen.blit(background, (0, 0))
                    Help = help.Help()
                    Help.display_help(screen)
                    while exit:
                        clock.tick(60)
                        exit = Help.no_exit()
                    screen.blit(background, (0, 0))
                if player1.state:
                    player1.select(player2) #select function of Player
                else:
                    player2.select(player1)
            elif event.type == pygame.MOUSEBUTTONUP:
                if player1.state:
                    player1.launch() # launch function of Player
                else:
                    player2.launch()
        

        '''code to draw the predicted trajectory'''
        mouse_x,mouse_y = pygame.mouse.get_pos()
        if player1.state:
            if player1.launching:
                background.blit(background_image,(0,0))
                pygame.draw.line(background,(0,0,0),(HEIGHT/2 + ((player1.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-410)+10,WIDTH-175+20),(mouse_x+15,mouse_y+20),5) #sling
                pygame.draw.line(background,(0,0,0),(HEIGHT/2 + ((player1.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-410)+30,WIDTH-175+20),(mouse_x+15,mouse_y+20),5)
                diff_x = HEIGHT/2 + ((player1.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-410) - mouse_x
                diff_y = WIDTH-175-mouse_y
                TIME = 0.1
                if diff_x!=0:
                    x = np.arange(mouse_x+diff_x/10,3*HEIGHT/4,diff_x/10)
                    vy = np.arange(diff_y/10,diff_y/10+WIDTH*TIME,TIME)
                    y = [mouse_y]
                    y = np.array(y)
                    y = y + vy.cumsum()
                    for i,x1 in enumerate(x):
                        if i%5==0:
                            y1 = y[i]
                            circle = pygame.draw.circle(background,(200,100,200),(x1+15,y1+20),5)
                            done = False
                            for block in player2.blocks_list:
                                if circle.colliderect(block.rect):
                                    done = True
                                    break
                            if y1 > WIDTH - 105 or y1 < 0:
                                done = True
                            if done:
                                break
                    
            if player1.firing:
                background.blit(background_image,(0,0))
            player1.fire(player2)
            if level_no!=1 and (pygame.sprite.collide_rect(player1.sling,obstacle1) or pygame.sprite.collide_rect(obstacle1,player1.sling)):
                obstacle_hit = load_sound("stone_hit.wav")
                obstacle_hit.play()
                player1.state,player2.state = player2.state,player1.state
                player1.reset()

            
        else:
            if player2.launching:
                background.blit(background_image,(0,0))
                pygame.draw.line(background,(0,0,0),(HEIGHT/2 + ((player2.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-410),WIDTH-175+20),(mouse_x+15,mouse_y+20),5)
                pygame.draw.line(background,(0,0,0),(HEIGHT/2 + ((player2.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-410)+20,WIDTH-175+20),(mouse_x+15,mouse_y+20),5)
                diff_x = HEIGHT/2 + ((player2.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-410) - mouse_x
                diff_y = WIDTH-175-mouse_y
                TIME = 0.1
                if diff_x!=0:
                    x = np.arange(mouse_x+diff_x/10,HEIGHT/4,diff_x/10)
                    vy = [diff_y/10]
                    vy = np.arange(diff_y/10,diff_y/10+WIDTH*TIME,TIME)
                    y = [mouse_y]
                    y = np.array(y)
                    y = y + vy.cumsum()
                    for i,x1 in enumerate(x):
                        if i%5==0:
                            y1 = y[i]
                            circle = pygame.draw.circle(background,(200,100,200),(x1+15,y1+20),5)
                            done = False
                            for block in player1.blocks_list:
                                if circle.colliderect(block.rect):
                                    done = True
                                    break
                            if y1 > WIDTH - 105:
                                done = True
                            if done:
                                break
            if player2.firing:
                background.blit(background_image,(0,0))
            player2.fire(player1)
            if level_no!=1 and (pygame.sprite.collide_rect(player2.sling,obstacle1) or pygame.sprite.collide_rect(obstacle1,player2.sling)):
                obstacle_hit = load_sound("stone_hit.wav")
                obstacle_hit.play()
                player1.state,player2.state = player2.state,player1.state
                player2.reset()

        '''render sprites, texts and slingshots to the display'''
        player1.all_sprites.update()
        player2.all_sprites.update()
        screen.blit(background, (0, 0))
        player_text = (player1_name if player1.state else player2_name) + " playing"
        render_text(screen,font,player_text,(204,51,139),(HEIGHT/2,WIDTH/2 - 50))
        player1_text = player1_name
        render_text(screen,font,player1_text,(0,255,239),(HEIGHT/4,WIDTH - 50))
        player2_text = player2_name
        render_text(screen,font,player2_text,(0,255,239),(3*HEIGHT/4,WIDTH - 50))
        slingshot = pygame.image.load('images/slingshot.png').convert_alpha()
        slingshot = pygame.transform.scale_by(slingshot,1.1)
        screen.blit(slingshot,(400,WIDTH-175))
        #print(slingshot.get_rect().topleft)
        flip_slingshot = pygame.image.load('images/slingshot.png').convert_alpha()
        flip_slingshot = pygame.transform.flip(flip_slingshot, True, False)
        flip_slingshot = pygame.transform.scale_by(flip_slingshot,1.1)
        screen.blit(flip_slingshot,(HEIGHT-420,WIDTH-175))
        screen.blit(info_button, (HEIGHT-45, 5))
        player1.all_sprites.draw(screen)
        player2.all_sprites.draw(screen)

        '''check for winning condition'''
        if player1.blocks_list == []:
            winner = "player2"
            going = False
        if player2.blocks_list == []:
            winner = "player1"
            going = False
        pygame.display.flip()

    '''game over'''
    player1.state = False
    player2.state = False   
    print(winner)
    going1 = True
    button_sound = load_sound("button_clicked.wav")
    victory = load_sound("victory.wav")
    if winner!=None:
        victory.play() #play the victory sound if there actually is a winner

    '''winner display loop'''
    while going1:
        screen.blit(background, (0, 0))
        winner_text = "Winner:"+(player1_name if winner=="player1" else (player2_name if winner=="player2" else "None"))
        render_text(screen,font,winner_text,(204,51,139),(HEIGHT/2,WIDTH/3))
        trophy = pygame.image.load("images/trophy1.png").convert_alpha()
        trophy = pygame.transform.scale(trophy,(120,216))
        if winner!=None:
            screen.blit(trophy,(HEIGHT/2-60,WIDTH/2+40)) #display a trophy if there actually is a winner
        replay = pygame.image.load("images/replay.png").convert_alpha()
        screen.blit(replay,(HEIGHT/4,WIDTH/2))
        menu_button = pygame.image.load("images/menu_button.png").convert_alpha()
        screen.blit(menu_button,(3*HEIGHT/4,WIDTH/2))
        next_button = pygame.image.load("images/next_level.png").convert_alpha()
        screen.blit(info_button, (HEIGHT-45, 5))
        if level_no != 3:
            screen.blit(next_button,(5*HEIGHT/8,3*WIDTH/4))
        back_button = pygame.transform.flip(next_button,True,False)
        if level_no != 1:
            screen.blit(back_button,(3*HEIGHT/8,3*WIDTH/4))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                going1 = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                going1 = False
                sys.exit(0)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                '''replay and menu button functionalities'''
                mouse_X,mouse_Y = pygame.mouse.get_pos()
                if HEIGHT - 45 < mouse_X < HEIGHT-5 and 5 < mouse_Y < 45:
                    button.play()
                    exit = True
                    screen.blit(background, (0, 0))
                    Help = help.Help()
                    Help.display_help(screen)
                    while exit:
                        clock.tick(60)
                        exit = Help.no_exit()
                    screen.blit(background, (0, 0))
                if HEIGHT/4 <= mouse_X <= HEIGHT/4+60 and WIDTH/2 <= mouse_Y <= WIDTH/2 + 60:
                    button_sound.play()
                    going1 = False
                    pygame.quit()
                    pygame.init()
                    pygame.display.set_caption("Angry Birds")
                    game(p1,p2,level_no)
                elif 3*HEIGHT/4 <= mouse_X <= 3*HEIGHT/4+60 and WIDTH/2 <= mouse_Y <= WIDTH/2 + 60:
                    button_sound.play()
                    going1 = False
                    pygame.quit()
                    pygame.init()
                    pygame.display.set_caption("Angry Birds")
                    p1,p2,level_no = menu.menu(Going=False)
                    game(p1,p2,level_no)
                elif level_no!=1 and 3*HEIGHT/8 <= mouse_X <= 3*HEIGHT/8+60 and 3*WIDTH/4 <= mouse_Y <= 3*WIDTH/4 + 60:
                    button_sound.play()
                    going1 = False
                    pygame.quit()
                    pygame.init()
                    pygame.display.set_caption("Angry Birds")
                    game(p1,p2,level_no - 1)
                elif level_no!=3 and 5*HEIGHT/8 <= mouse_X <= 5*HEIGHT/8+60 and 3*WIDTH/4 <= mouse_Y <= 3*WIDTH/4 + 60:
                    button_sound.play()
                    going1 = False
                    pygame.quit()
                    pygame.init()
                    pygame.display.set_caption("Angry Birds")
                    game(p1,p2,level_no + 1)
        pygame.display.flip()