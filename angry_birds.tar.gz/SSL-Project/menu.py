import pygame
import sys
import help
HEIGHT = 1280
WIDTH = 600

'''code for the menu part of the game'''

def load_sound(name): #function to load sound; if the mixer is unavailable it does nothing instead of throwing error
    class NoneSound:
        def play(self): #if the code asks to play the sound but the mixer is unavailable, it does nothing
            pass
    if not pygame.mixer.get_init():
        return NoneSound()
    fullname = "sounds/" + name
    sound = pygame.mixer.Sound(fullname)
    return sound

'''card class for making cards to select the levels'''

class Card():
    def __init__(self,number,colour,position):
        self.number = number
        self.colour = colour
        self.position = position
        self.rect = pygame.Rect(position[0],position[1],HEIGHT/5,WIDTH/2)

    def place_card(self,surface,card_title,logo,photo):
        pygame.draw.rect(surface, self.colour, self.rect ,border_radius = 10) 
        surface.blit(card_title,(self.position[0] + HEIGHT/10 - card_title.get_width()/2, self.rect.y+WIDTH/9))
        surface.blit(logo,(self.rect.x+5, self.rect.y+5))  
        surface.blit(photo,(self.rect.x+5, self.rect.y+WIDTH/5))

def menu(Going=True):
    pygame.font.init()
    screen = pygame.display.set_mode((HEIGHT, WIDTH), pygame.SCALED)
    theme = load_sound("menu_theme.mp3")
    theme.play(loops = -1) #play the theme song over and over
    '''setting up the background'''
    background_image = pygame.image.load('images/background_2.png').convert()
    background_image = pygame.transform.scale(background_image,(HEIGHT,WIDTH))
    background = pygame.Surface(screen.get_size())
    background = background.convert()
    background.blit(background_image,(0,0))
    screen.blit(background, (0, 0))
    pygame.display.flip()
    font = pygame.font.Font("fonts/FeastOfFleshBb-AVm.ttf",WIDTH//15)
    play_image = pygame.image.load("images/play_button.png")
    play_image = pygame.transform.scale(play_image,(168,80))
    screen.blit(play_image, (HEIGHT/2-84,WIDTH/2-40))
    clock = pygame.time.Clock()

    button = load_sound("button_clicked.wav")
    sound_button = pygame.image.load("images/mute.png")
    sound_button_imagename = "mute.png"
    info_button = pygame.image.load("images/info_button.png")
    logo = pygame.image.load("images/logo.png").convert_alpha()
    logo = pygame.transform.scale(logo,(500,200))
    going = Going
    while going:
        '''loop for the "play" screen'''
        clock.tick(60)
    
        screen.blit(logo,(HEIGHT/2-250,50))
        for event in pygame.event.get():   
            if event.type == pygame.QUIT:
                going = False
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                going = False
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN: 
                mouse_x,mouse_y = pygame.mouse.get_pos()
                if HEIGHT/2 - 100 < mouse_x < HEIGHT/2 + 100 and WIDTH/2 - 40 < mouse_y < WIDTH/2 + 40:
                    print("Play done")
                    going = False
                    button.play()
                if 5 < mouse_x < 55 and WIDTH - 55 < mouse_y < WIDTH - 5:
                    if sound_button_imagename=="mute.png":
                        theme.stop()
                        sound_button = pygame.image.load("images/unmute.png")
                        sound_button_imagename = "unmute.png"
                    elif sound_button_imagename=="unmute.png":
                        theme.play(loops = -1)
                        sound_button = pygame.image.load("images/mute.png")
                        sound_button_imagename = "mute.png"
                    button.play()
                if 5 < mouse_x < 45 and WIDTH - 200 < mouse_y < WIDTH - 160:
                    exit = True
                    screen.blit(background, (0, 0))
                    Help = help.Help()
                    Help.display_help(screen)
                    while exit:
                        clock.tick(60)
                        exit = Help.no_exit()
                    screen.blit(background, (0, 0))

        screen.blit(play_image, (HEIGHT/2-84,WIDTH/2-40))
        screen.blit(sound_button, (10,WIDTH-55))
        screen.blit(info_button, (10, WIDTH-200))
        pygame.display.flip()
    level_no = 0
    going1 = True
    screen.blit(background, (0, 0))
    while going1:
        '''loop for the levels screen'''
        clock.tick(60)
        logo1 = pygame.transform.scale(logo,(HEIGHT/5 - 10 ,WIDTH/8))
        level1_photo = pygame.image.load("images/level1_photo.png").convert_alpha()
        level1_photo = pygame.transform.scale(level1_photo,(HEIGHT/5 - 10, WIDTH/4))
        level2_photo = pygame.image.load("images/level2_photo.png").convert_alpha()
        level2_photo = pygame.transform.scale(level2_photo,(HEIGHT/5 - 10, WIDTH/4))
        level3_photo = pygame.image.load("images/level3_photo.png").convert_alpha()
        level3_photo = pygame.transform.scale(level3_photo,(HEIGHT/5 - 10, WIDTH/4))
        card1 = Card(1,(0,255,100),(HEIGHT/5 - 10, WIDTH/4))
        card1_title = font.render("Level 1",True,(255,255,255))
        card1.place_card(screen,card1_title,logo1,level1_photo)
        card2 = Card(2,(255,100,0),(2*HEIGHT/5, WIDTH/4))
        card2_title = font.render("Level 2",True,(255,255,255))
        card2.place_card(screen,card2_title,logo1,level2_photo)
        card3 = Card(3,(100,0,255),(3*HEIGHT/5 + 10, WIDTH/4)) 
        card3_title = font.render("Level 3",True,(255,255,255))
        card3.place_card(screen,card3_title,logo1,level3_photo)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                going1 = False
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                going1 = False
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x1,mouse_y1 = pygame.mouse.get_pos()
                '''if any of the cards are touched, the loop should break and the desired level number should be stored'''
                if card1.rect.collidepoint(event.pos):
                    level_no = 1
                    going1 = False
                    button.play()
                if card2.rect.collidepoint(event.pos):
                    level_no = 2
                    going1 = False
                    button.play()
                if card3.rect.collidepoint(event.pos):
                    level_no = 3
                    going1 = False
                    button.play()
                if 5 < mouse_x1 < 55 and WIDTH - 55 < mouse_y1 < WIDTH - 5:
                    if sound_button_imagename=="mute.png":
                        theme.stop()
                        sound_button = pygame.image.load("images/unmute.png")
                        sound_button_imagename = "unmute.png"
                    elif sound_button_imagename=="unmute.png":
                        theme.play(loops = -1)
                        sound_button = pygame.image.load("images/mute.png")
                        sound_button_imagename = "mute.png"
                    button.play()
                if 5 < mouse_x1 < 45 and WIDTH - 200 < mouse_y1 < WIDTH - 160:
                    button.play()
                    exit = True
                    screen.blit(background, (0, 0))
                    Help = help.Help()
                    Help.display_help(screen)
                    while exit:
                        clock.tick(60)
                        exit = Help.no_exit()
                    screen.blit(background, (0, 0))
        screen.blit(sound_button, (10,WIDTH-55))
        screen.blit(info_button, (10, WIDTH-200))
        pygame.display.flip()
                
    going2 = True
    screen.blit(background, (0, 0))
    input_rect1 = pygame.Rect(HEIGHT//2-350,WIDTH//2-130,700,45)
    input_rect2 = pygame.Rect(HEIGHT//2-350,WIDTH//2-70,700,45)
    active1 = False
    active2 = False
    player1_text = ""
    player2_text = ""
    while going2:
        '''loop for player names screen'''
        clock.tick(60)
        for event in pygame.event.get():    
            if event.type == pygame.MOUSEBUTTONDOWN:
                '''when the textbox is clicked, the user should be able to type in it'''
                if input_rect1.collidepoint(event.pos):
                    active1 = not active1
                else:
                    active1 = False
                if input_rect2.collidepoint(event.pos):
                    active2 = not active2
                else:
                    active2 = False
                mouse_X,mouse_Y = pygame.mouse.get_pos()
                if HEIGHT/2-40 < mouse_X < HEIGHT/2+60 and WIDTH/2 + 50 < mouse_Y < WIDTH/2 + 90:
                    '''start button should break the loop only if both players' names are filled'''
                    if active1:
                        active1 = False
                    if active2:
                        active2 = False
                    if player1_text and player2_text:
                        going2 = False
                        button.play()
                if 5 < mouse_X < 45 and WIDTH - 200 < mouse_Y < WIDTH - 160:
                    button.play()
                    exit = True
                    screen.blit(background, (0, 0))
                    Help = help.Help()
                    Help.display_help(screen)
                    while exit:
                        clock.tick(60)
                        exit = Help.no_exit()
                    screen.blit(background, (0, 0))
            if event.type == pygame.QUIT:
                going2 = False
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                going2 = False
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:
                    if active1:
                        player1_text = player1_text[:-1]
                    if active2:
                        player2_text = player2_text[:-1]
                elif event.key == pygame.K_RETURN:
                    if active1:
                        active1 = False
                    if active2:
                        active2 = False
                    if player1_text and player2_text:
                        going2 = False
                else:
                    if active1:
                        player1_text += event.unicode
                    if active2:
                        player2_text += event.unicode
        wooden_plank = pygame.image.load("images/woodenplank.png").convert_alpha()
        FACTOR_X = 0.8
        FACTOR_Y = 0.3
        '''display everything to the screen'''
        wooden_plank = pygame.transform.scale_by(wooden_plank,(FACTOR_X,FACTOR_Y))
        screen.blit(wooden_plank,(HEIGHT/2 - 1000*FACTOR_X/2, WIDTH/2 - 1400*FACTOR_Y/2 - 30))
        start_button = pygame.image.load("images/start_button.png")
        start_button = pygame.transform.scale_by(start_button,0.2)
        screen.blit(start_button,(HEIGHT/2 - 40, WIDTH/2 + 50))
        chuck_image = pygame.image.load("images/chuck.png").convert_alpha()
        flip_chuck_image = pygame.transform.flip(chuck_image,True,False)
        red_image = pygame.image.load("images/red.png").convert_alpha()
        flip_red_image = pygame.transform.flip(red_image,True,False)
        blues_image = pygame.image.load("images/blues.png").convert_alpha()
        flip_blues_image = pygame.transform.flip(blues_image,True,False)
        bomb_image = pygame.image.load("images/bomb.png").convert_alpha()
        flip_bomb_image = pygame.transform.flip(bomb_image,True,False)
        screen.blit(red_image,(HEIGHT/2 - 200, WIDTH/2 - 1400*FACTOR_Y/2 -50))
        screen.blit(flip_red_image,(HEIGHT/2 + 200, WIDTH/2 - 1400*FACTOR_Y/2 - 50))
        screen.blit(chuck_image,(HEIGHT/2 - 350, WIDTH - 190))
        screen.blit(flip_chuck_image,(HEIGHT/2 + 350, WIDTH - 190))
        screen.blit(blues_image,(HEIGHT/2 - 350, WIDTH/2 - 1400*FACTOR_Y/2 -50))
        screen.blit(flip_blues_image,(HEIGHT/2 + 350, WIDTH/2 - 1400*FACTOR_Y/2 -50))
        screen.blit(bomb_image,(HEIGHT/2 - 200, WIDTH - 190))
        screen.blit(flip_bomb_image,(HEIGHT/2 + 200, WIDTH - 190))
        text_surface3 = font.render("Who's playing?",True,(96,75,0))
        text_rect3 = text_surface3.get_rect(center = (HEIGHT/2,WIDTH/2 - 175))
        screen.blit(text_surface3,text_rect3)
        pygame.draw.rect(screen, (96,75,0), input_rect1,border_radius = 10) 
        text_surface1 = font.render(player1_text, True, (255, 255, 255))
        text_surface_title1 = font.render("Player 1:",True,(255,255,255))
        screen.blit(text_surface_title1,(input_rect1.x+5, input_rect1.y+5)) 
        screen.blit(text_surface1, (input_rect1.x + text_surface_title1.get_width() + 10, input_rect1.y+5)) 
        input_rect1.w = max(700, text_surface1.get_width()+10,text_surface_title1.get_width()+10)
        pygame.draw.rect(screen, (96,75,0), input_rect2, border_radius = 10) 
        text_surface2 = font.render(player2_text, True, (255, 255, 255)) 
        text_surface_title2 = font.render("Player 2:",True,(255,255,255))
        screen.blit(text_surface_title2,(input_rect2.x+5, input_rect2.y+5)) 
        screen.blit(text_surface2, (input_rect2.x + text_surface_title2.get_width() + 10, input_rect2.y+5)) 
        input_rect2.w = max(700, text_surface2.get_width()+10,text_surface_title2.get_width()+10) 
        screen.blit(info_button, (10, WIDTH-200))
        pygame.display.flip() 
    theme.stop() #stop playing the theme song once out of the menu
    return player1_text,player2_text,level_no
