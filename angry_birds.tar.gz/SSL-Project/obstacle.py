import pygame

HEIGHT = 1280
WIDTH = 600
'''code for the obstacle in levels 2 and 3'''
class Obstacle(pygame.sprite.Sprite):
    def __init__(self,level_no):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("images/obstacle.png")
        self.image = pygame.transform.scale_by(self.image,0.5)
        self.rect = self.image.get_rect()
        self.level_no = level_no
        self.speed = [0,1*(4-self.level_no)]

    def update(self):
        if self.level_no == 2:
            self.rect = self.rect.move(self.speed)
            if self.rect.bottom > WIDTH-75:
                self.rect.bottom = WIDTH - 80
                self.speed[1] = -self.speed[1]
            elif self.rect.top < 0:
                self.rect.top = 0
                self.speed[1] = -self.speed[1]
        if self.level_no == 3:
            self.rect = self.rect.move(self.speed)
            if self.rect.bottom > WIDTH-75:
                self.rect.bottom = WIDTH - 75
                self.speed[1] = -self.speed[1]
            elif self.rect.top < 0:
                self.rect.top = 0
                self.speed[1] = -self.speed[1]
            self.speed[1]+=0.05
