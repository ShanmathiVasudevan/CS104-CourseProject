import pygame
import birds
import blocks
import level
import numpy as np

'''code that defines the player object'''

HEIGHT = 1280
WIDTH = 600

def load_sound(name):
    class NoneSound:
        def play(self):
            pass
    if not pygame.mixer.get_init():
        return NoneSound()
    fullname = "sounds/" + name
    sound = pygame.mixer.Sound(fullname)
    return sound

class Player:
    def __init__(self,position_x,level_no):
        '''position_x helps decide the position of the blocks depending on the side of the screen the object is on
        the formula HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-(number)) is used because I didn't want to write 2 separate codes depending on whether the player was on the left of the screen or the right
        if the player is on the left of the screen, position_x is given as 0, and the distance of the object from the left of the screen is (number)
        if the player is on the right of the screen, position_x is given as HEIGHT, and the distance of the object from the right of the screen is (number)
        
        level_no decides the blocks in the tower of the player'''
        self.state = False
        self.position_x = position_x
        self.level_no = level_no
        self.birdie = None
        self.sling = birds.Sling("transparent.png")
        self.bird1 = birds.Bird("bomb.png", HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-300), WIDTH-90)
        self.bird2 = birds.Bird("chuck.png", HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-250), WIDTH-90)
        self.bird3 = birds.Bird("red.png", HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-200), WIDTH-90)
        self.bird4 = birds.Bird("blues.png", HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-150), WIDTH-90)
        self.birds_list = [self.bird1, self.bird2, self.bird3, self.bird4]
        if HEIGHT/2<position_x:
            self.bird1.image = pygame.transform.flip(self.bird1.image,True,False)
            self.bird2.image = pygame.transform.flip(self.bird2.image,True,False)
            self.bird3.image = pygame.transform.flip(self.bird3.image,True,False)
            self.bird4.image = pygame.transform.flip(self.bird4.image,True,False)
        if level_no == 1:
            levelno = level.Level1(self.position_x)
        if level_no == 2:
            levelno = level.Level2(self.position_x)
        if level_no == 3:
            levelno = level.Level3(self.position_x)
        self.blocks_list = levelno.blocks_list
        levelno.place_blocks()
        self.all_sprites = pygame.sprite.Group((self.bird1, self.bird2, self.bird3, self.bird4, self.sling))
        for block in self.blocks_list:
            block.add(self.all_sprites)

        self.launching = False
        self.firing = False
        self.speed = np.array([0,0])

    def regenerate(self): #code to regenerate the birds once the player has used them all
        if self.bird1.imagename==self.bird2.imagename==self.bird3.imagename==self.bird4.imagename=="transparent.png":
            self.bird1.imagename="bomb.png"
            self.bird1.image, self.bird1.rect = birds.load_image("bomb.png", -1, 0.6)
            self.bird1.rect.center = HEIGHT/2 + ((self.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-300), WIDTH-90
            self.bird2.imagename="chuck.png"
            self.bird2.image, self.bird2.rect = birds.load_image("chuck.png", -1, 0.6)
            self.bird2.rect.center = HEIGHT/2 + ((self.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-250), WIDTH-90
            self.bird3.imagename="red.png"
            self.bird3.image, self.bird3.rect = birds.load_image("red.png", -1, 0.6)
            self.bird3.rect.center = HEIGHT/2 + ((self.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-200), WIDTH-90
            self.bird4.imagename="blues.png"
            self.bird4.image, self.bird4.rect = birds.load_image("blues.png", -1, 0.6)
            self.bird4.rect.center = HEIGHT/2 + ((self.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-150), WIDTH-90
            if HEIGHT/2<self.position_x:
                self.bird1.image = pygame.transform.flip(self.bird1.image,True,False)
                self.bird2.image = pygame.transform.flip(self.bird2.image,True,False)
                self.bird3.image = pygame.transform.flip(self.bird3.image,True,False)
                self.bird4.image = pygame.transform.flip(self.bird4.image,True,False)
    
    def reset(self): 
        ''' once the bird dies, the sling object should return to the slingshot and not have a bird on it. 
        The bird on the floor should also vanish as it cannot be used again till all other birds have been used'''
        self.speed = np.array([0,0])
        self.firing = False
        self.sling.imagename="transparent.png"
        self.sling.image, self.sling.rect = birds.load_image("transparent.png", -1, 0.5)
        #self.fist_offset = (-235, -80) 
        self.sling.rect.topleft = HEIGHT/2 + ((self.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-410), WIDTH - 175
        self.birdie.vanish = True

    def select(self,Player2): 
        '''this function is for mouse-down events'''
        if self.firing: #for the special powers of the birds
            if self.sling.imagename == "chuck.png": #increase its speed
                self.speed*=3
            if self.sling.imagename == "bomb.png": #damage blocks around it
                self.sling.rect = self.sling.rect.scale_by(10)
                explode = load_sound("explosion.wav")
                explode.play()
                for block in Player2.blocks_list:
                    if pygame.sprite.collide_rect(self.sling,block) or pygame.sprite.collide_rect(block,self.sling):
                        print("Hit",self.sling.imagename,block.properties)
                        block.hit(self.sling)
                        if block.properties['health']<=1:
                            block.properties['health']=0
                            Player2.blocks_list.remove(block)
                self.state,Player2.state = Player2.state,self.state
                self.reset()

            if self.sling.imagename == "blues.png": #make it go upwards - based on the white bird's power in angry birds
                self.speed[0]*=0.5
                if self.speed[1]>0:
                    self.speed[1]*=-1
                self.speed[1]*=3
                if self.speed[1]>-1:
                    self.speed[1]-=10
                if self.speed[1]<-20:
                    self.speed[1]+=10
        else: #mousedown events when the bird is not firing
            mouse_x,mouse_y = pygame.mouse.get_pos()
            #print(mouse_x,mouse_y)
            if self.sling.imagename!="transparent.png" and self.sling.rect.topleft[0]-40<mouse_x<self.sling.rect.topleft[0]+40 and self.sling.rect.topleft[1]-40<mouse_y<self.sling.rect.topleft[1]+40:
                '''when the bird on the slingshot is clicked (and subsequently dragged)'''
                print("Ready to Launch")
                self.launching = True
                self.sling.launch()
                sling_sound = load_sound("slingshot.wav")
                sling_sound.play()
            for bird in self.birds_list:
                if bird.rect.topleft[0]<mouse_x<bird.rect.topleft[0]+40 and bird.rect.topleft[1]-40<mouse_y<bird.rect.topleft[1]+40:
                    '''if any of the birds on the floor are clicked, it should appear on the slingshot'''
                    self.sling.imagename=bird.imagename
                    self.sling.image, self.sling.rect = birds.load_image(bird.imagename, -1, 0.5)
                    if HEIGHT/2<self.position_x:
                        self.sling.image = pygame.transform.flip(self.sling.image,True,False)
                    self.sling.rect.topleft = HEIGHT/2 + ((self.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-410), WIDTH - 175
                    self.birdie = bird
        
    def launch(self):
        '''decides the speed of launch'''
        print("Firing:",self.firing)
        mouse_x1,mouse_y1 = pygame.mouse.get_pos()
        #print(mouse_x1,mouse_y1)
        if self.launching:
            self.firing = True
            diff_x = HEIGHT/2 + ((self.position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-410) - mouse_x1
            diff_y = WIDTH-175-mouse_y1
            
            print("diff_x and diff_y to fire:",diff_x,diff_y)
            self.speed = np.array([diff_x/10,diff_y/10])
            self.sling.remove()
            self.launching = False

    def fire(self,Player2):
        '''controls the actual trajectory of the bird'''
        if self.firing:
            self.sling.rect = self.sling.rect.move(self.speed)
            changed = False
            for block in Player2.blocks_list:
                if pygame.sprite.collide_rect(self.sling,block) or pygame.sprite.collide_rect(block,self.sling): #if a block is hit
                    print("Hit",self.sling.imagename)
                    block.hit(self.sling) # lower the health of the blocks
                    block_name = block.properties['type']
                    if block.properties['health']<=1: # to prevent edge cases of say 3 chucks hitting a stone block not destroying the block
                        block.properties['health']=0
                        Player2.blocks_list.remove(block)
                        destroyed = load_sound(block_name + "_destroyed.wav")
                        destroyed.play()
                    else:
                        hit_block = load_sound(block_name + "_hit.wav")
                        hit_block.play()
                    self.state,Player2.state = Player2.state,self.state
                    changed = True
                    self.reset() #the bird dies when it hits a block.

            if self.sling.rect.left < 0 or self.sling.rect.right > HEIGHT or self.sling.rect.top < 0 or self.sling.rect.bottom > WIDTH-75: #if the bird hits the boundaries, it dies
                if not changed: #if the previous condition was already satisfied, don't change the player's state again
                    self.state,Player2.state = Player2.state,self.state
                self.reset()
            else:
                self.speed+=[0,0.1] # gravity simulation
        
        
