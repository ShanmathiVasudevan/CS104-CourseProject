import pygame
import blocks

HEIGHT = 1280
WIDTH = 600

'''code that defines the level objects and the types of levels'''

class Level():
    def __init__(self, position_x, number,blocks_list):
        self.position_x = position_x
        self.number = number
        self.blocks_list = blocks_list
    def place_blocks(self):
        for block in self.blocks_list:
            block.place_block()

class Level1(Level):
    def __init__(self,position_x):
        self.position_x = position_x
        self.number = 1
        self.block1 = blocks.Stone(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-95)
        self.block2 = blocks.Ice(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-120)
        self.block3 = blocks.Wood(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-75),WIDTH-170)
        self.block4 = blocks.Stone(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-220)
        self.block5 = blocks.Ice(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-255)
        self.block6 = blocks.Ice(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-40),WIDTH-170)
        self.block7 = blocks.Wood(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-80),WIDTH-305)
        self.block8 = blocks.Stone(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-45),WIDTH-305)
        self.blocks_list = [self.block1,self.block2,self.block3,self.block4,self.block5,self.block6,self.block7,self.block8]
        super().__init__(self.position_x,self.number,self.blocks_list)

class Level2(Level):
    def __init__(self,position_x):
        self.position_x = position_x
        self.number = 2
        self.block1 = blocks.Stone(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-95)
        self.block2 = blocks.Ice(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-120)
        self.block3 = blocks.Wood(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-75),WIDTH-170)
        self.block4 = blocks.Stone(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-220)
        self.block5 = blocks.Ice(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-255)
        self.block6 = blocks.Ice(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-40),WIDTH-170)
        self.block7 = blocks.Wood(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-80),WIDTH-305)
        self.block8 = blocks.Stone(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-45),WIDTH-305)
        self.block9 = blocks.Wood(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-355)
        self.block10 = blocks.Ice(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-390)
        self.blocks_list = [self.block1,self.block2,self.block3,self.block4,self.block5,self.block6,self.block7,self.block8,self.block9,self.block10]
        super().__init__(self.position_x,self.number,self.blocks_list)

class Level3(Level):
    def __init__(self,position_x):
        self.position_x = position_x
        self.number = 3
        self.block1 = blocks.Stone(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-95)
        self.block2 = blocks.Ice(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-120)
        self.block3 = blocks.Wood(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-75),WIDTH-170)
        self.block4 = blocks.Stone(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-220)
        self.block5 = blocks.Ice(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-255)
        self.block6 = blocks.Ice(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-40),WIDTH-170)
        self.block7 = blocks.Wood(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-80),WIDTH-305)
        self.block8 = blocks.Stone(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-45),WIDTH-305)
        self.block9 = blocks.Wood(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-355)
        self.block10 = blocks.Ice(0,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-60),WIDTH-390)
        self.block11 = blocks.Wood(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-40),WIDTH-440)
        self.block12 = blocks.Stone(90,HEIGHT/2 + ((position_x-HEIGHT/2)/(HEIGHT/2))*(HEIGHT/2-75),WIDTH-440)
        self.blocks_list = [self.block1,self.block2,self.block3,self.block4,self.block5,self.block6,self.block7,self.block8,self.block9,self.block10,self.block11,self.block12]
        super().__init__(self.position_x,self.number,self.blocks_list)