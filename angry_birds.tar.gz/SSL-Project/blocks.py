import pygame

'''code to define the blocks in the game'''

class Block(pygame.sprite.Sprite):
    def __init__(self,properties,orientation,position_x,position_y):
        pygame.sprite.Sprite.__init__(self)
        self.properties = properties
        self.orientation = orientation
        self.position = (position_x,position_y)

    def update(self):
        self.change_block()

    def place_block(self): # set up the block in the desired position
        fullname = "images/"+str(self.properties['type'])+"_block.png"
        self.image = pygame.image.load(fullname)
        self.image = self.image.convert_alpha()
        self.image = pygame.transform.scale(self.image,(65,35))
        self.image = pygame.transform.rotate(self.image,self.orientation)
        
        self.rect = self.image.get_rect()
        self.rect.center = self.position
    
    def change_block(self): # change the photo of the block depending on its current health
        if 34<self.properties['health']<=67:
            fullname = "images/"+str(self.properties['type'])+"_block_0.5.png"
            self.image = pygame.image.load(fullname)
            self.image = self.image.convert_alpha()
            self.image = pygame.transform.scale(self.image,(65,35))
            self.image = pygame.transform.rotate(self.image,self.orientation)
            self.rect = self.image.get_rect()
            self.rect.center = self.position
        elif 34>=self.properties['health']>1:
            fullname = "images/"+str(self.properties['type'])+"_block_0.25.png"
            self.image = pygame.image.load(fullname)
            self.image = self.image.convert_alpha()
            self.image = pygame.transform.scale(self.image,(65,35))
            self.image = pygame.transform.rotate(self.image,self.orientation)
            self.rect = self.image.get_rect()
            self.rect.center = self.position
        elif self.properties['health']<=1:
            self.properties['health']=0
            pygame.sprite.Sprite.kill(self)

    def hit(self,target=None): # if the block is hit by a bird, reduce its health depending on which bird hit it
        if target is not None and (pygame.sprite.collide_rect(target,self) or pygame.sprite.collide_rect(self,target)):
            name = target.imagename.split('.')[0]
            self.properties['health']-=round(33.33*self.properties['damage'][name])

'''defining the different types of blocks and their properties'''

class Wood(Block):
    def __init__(self,orientation,position_x,position_y):
        self.orientation = orientation
        self.position_x = position_x
        self.position_y = position_y

        self.properties = {'type':'wood','damage':{'red':2,'chuck':3,'bomb':1,'blues':1},'health':100}
        super().__init__(self.properties,self.orientation,self.position_x,self.position_y)

class Ice(Block):
    def __init__(self,orientation,position_x,position_y):
        self.orientation = orientation
        self.position_x = position_x
        self.position_y = position_y

        self.properties = {'type':'ice','damage':{'red':2,'chuck':1,'bomb':1,'blues':3},'health':100}
        super().__init__(self.properties,self.orientation,self.position_x,self.position_y)

class Stone(Block):
    def __init__(self,orientation,position_x,position_y):
        self.orientation = orientation
        self.position_x = position_x
        self.position_y = position_y

        self.properties = {'type':'stone','damage':{'red':2,'chuck':1,'bomb':3,'blues':1},'health':100}
        super().__init__(self.properties,self.orientation,self.position_x,self.position_y)


