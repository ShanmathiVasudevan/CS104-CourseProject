import pygame
HEIGHT = 1280
WIDTH = 600

'''code to define the birds in the game - the object on the sling and the objects on the floor'''

def load_image(name, colorkey=None, scale=1.0): #loads image and returns the surface and rect objects
    fullname = "images/"+name
    image = pygame.image.load(fullname)
    image = image.convert()
    image = pygame.transform.scale_by(image, scale)
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey, pygame.RLEACCEL)
    return image, image.get_rect()

class Sling(pygame.sprite.Sprite): #the bird on the slingshot
    def __init__(self,image):
        pygame.sprite.Sprite.__init__(self)
        self.imagename=image
        self.image, self.rect = load_image(image, -1, 0.6)
        self.rect.topleft = 410, WIDTH - 175
        self.selected = False

    def update(self):
        if self.selected: # makes the bird move with mouse position
            pos = pygame.mouse.get_pos()
            self.rect.topleft = pos

    def launch(self): # the bird should only move with mouse position when it has been clicked and is being dragged
        if not self.selected:
            self.selected = True

    def remove(self): # the bird should not move with mouse position once it is released
        self.selected = False

class Bird(pygame.sprite.Sprite): # the birds on the floor
    def __init__(self,image,deploy_x,deploy_y):
        pygame.sprite.Sprite.__init__(self)
        self.imagename=image
        self.image, self.rect = load_image(image, -1, 0.6)
        screen = pygame.display.get_surface()
        self.area = screen.get_rect()
        self.rect.center = deploy_x, deploy_y
        self.vanish = False

    def update(self):
        if self.vanish: # if the bird has been used, it should vanish from the floor
            self.imagename="transparent.png"
            self.image, self.rect = load_image("transparent.png", -1, 0.5)
            self.vanish = False
