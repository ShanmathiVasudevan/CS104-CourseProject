import pygame
HEIGHT = 1280
WIDTH = 600
'''code for the help button'''
class Help():
    def __init__(self):
        self.colour = (128,213,255)
        self.position = (10,10)
        self.rect = pygame.Rect(self.position[0],self.position[1],HEIGHT-20,WIDTH-20)
        self.font = pygame.font.Font("fonts/FeastOfFleshBb-AVm.ttf",WIDTH//30)
        self.bigfont = pygame.font.Font("fonts/FeastOfFleshBb-AVm.ttf",WIDTH//20)
        self.text_colour = (0,0,100)

    def display_help(self,surface):
        '''this is the content of the help button'''
        pygame.draw.rect(surface, self.colour, self.rect ,border_radius = 10) 
        text0 = "How to play?"
        text1 = "=> Click on PLAY"
        text2 = "=> Select the level you want to play"
        text3 = "=> Click on the textboxes to enter your names, and click on START (or press the RETURN/ENTER key on your keyboard) to start the game!"
        text4 = "=> On your turn, click, drag and release to fire your birds at your opponent's tower!"
        text5 = "=> Play ends when one tower is completely destroyed!"
        text6 = "Meet the birds!"
        text7 = "Red - does balanced damage to all blocks"
        text8 = "Chuck - does more damage to Wood and less to others. Click on the screen while he's in flight to speed him up!"
        text9 = "Bomb - does more damage to Stone and less to others. Click on the screen while he's in flight to make him explode!"
        text10 = "Blue - does more damage to Ice and less to others. Click on the screen while he's in flight to launch him high in the air!"
        text11 = "Buttons"
        text12 = "Replay - play the same level with the same players"
        text13 = "Menu - select a different level with different players"
        text14 = "Next level - play the next level with the same players"
        text15 = "Previous level - play the previous level with the same players"
        text16 = "Mute/unmute background music"
        text17 = "Help"
        text_surface = self.bigfont.render(text0,True,self.text_colour)
        surface.blit(text_surface,(self.rect.x+5, self.rect.y+5)) 
        text_surface1 = self.font.render(text1,True,self.text_colour)
        surface.blit(text_surface1,(self.rect.x+10, self.rect.y+35))
        text_surface2 = self.font.render(text2,True,self.text_colour)
        surface.blit(text_surface2,(self.rect.x+10, self.rect.y+65))
        text_surface3 = self.font.render(text3,True,self.text_colour)
        surface.blit(text_surface3,(self.rect.x+10, self.rect.y+95))
        text_surface4 = self.font.render(text4,True,self.text_colour)
        surface.blit(text_surface4,(self.rect.x+10, self.rect.y+125))
        text_surface5 = self.font.render(text5,True,self.text_colour)
        surface.blit(text_surface5,(self.rect.x+10, self.rect.y+155))
        text_surface6 = self.bigfont.render(text6,True,self.text_colour)
        surface.blit(text_surface6,(self.rect.x+5, self.rect.y+180)) 
        text_surface7 = self.font.render(text7,True,self.text_colour)
        surface.blit(text_surface7,(self.rect.x+10, self.rect.y+215))
        text_surface8 = self.font.render(text8,True,self.text_colour)
        surface.blit(text_surface8,(self.rect.x+10, self.rect.y+245))
        text_surface9 = self.font.render(text9,True,self.text_colour)
        surface.blit(text_surface9,(self.rect.x+10, self.rect.y+275))
        text_surface10 = self.font.render(text10,True,self.text_colour)
        surface.blit(text_surface10,(self.rect.x+10, self.rect.y+305))
        text_surface11 = self.bigfont.render(text11,True,self.text_colour)
        surface.blit(text_surface11,(self.rect.x+5, self.rect.y+330))
        text_surface12 = self.font.render(text12,True,self.text_colour)
        surface.blit(text_surface12,(self.rect.x+10, self.rect.y+365))
        text_surface13 = self.font.render(text13,True,self.text_colour)
        surface.blit(text_surface13,(self.rect.x+10, self.rect.y+395))
        text_surface14 = self.font.render(text14,True,self.text_colour)
        surface.blit(text_surface14,(self.rect.x+10, self.rect.y+425))
        text_surface15 = self.font.render(text15,True,self.text_colour)
        surface.blit(text_surface15,(self.rect.x+10, self.rect.y+455))
        text_surface16 = self.font.render(text16,True,self.text_colour)
        surface.blit(text_surface16,(self.rect.x+10, self.rect.y+485))
        text_surface17 = self.font.render(text17,True,self.text_colour)
        surface.blit(text_surface17,(self.rect.x+10, self.rect.y+515))
        ok_button = pygame.image.load("images/ok.png")
        red = pygame.image.load("images/red.png")
        red = pygame.transform.scale(red,(20,20))
        chuck = pygame.image.load("images/chuck.png")
        chuck = pygame.transform.scale(chuck,(20,20))
        bomb = pygame.image.load("images/bomb.png")
        bomb = pygame.transform.scale(bomb,(20,20))
        blue = pygame.image.load("images/blues.png")
        blue = pygame.transform.scale(blue,(20,20))
        replay = pygame.image.load("images/replay.png")
        replay = pygame.transform.scale(replay,(30,30))
        menu_button = pygame.image.load("images/menu_button.png")
        menu_button = pygame.transform.scale(menu_button,(30,30))
        next_level = pygame.image.load("images/next_level.png")
        next_level = pygame.transform.scale(next_level,(30,30))
        back_level = pygame.transform.flip(next_level,True,False)
        back_level = pygame.transform.scale(back_level,(30,30))
        mute = pygame.image.load("images/mute.png")
        mute = pygame.transform.scale(mute,(30,30))
        info_button = pygame.image.load("images/info_button.png")
        info_button = pygame.transform.scale(info_button,(30,30))
        surface.blit(red,(self.rect.x+text_surface7.get_width()+20,self.rect.y+215))
        surface.blit(chuck,(self.rect.x+text_surface8.get_width()+20,self.rect.y+245))
        surface.blit(bomb,(self.rect.x+text_surface9.get_width()+20,self.rect.y+275))
        surface.blit(blue,(self.rect.x+text_surface10.get_width()+20,self.rect.y+305))
        surface.blit(replay,(self.rect.x+text_surface12.get_width()+20,self.rect.y+365))
        surface.blit(menu_button,(self.rect.x+text_surface13.get_width()+20,self.rect.y+395))
        surface.blit(next_level,(self.rect.x+text_surface14.get_width()+20,self.rect.y+425))
        surface.blit(back_level,(self.rect.x+text_surface15.get_width()+20,self.rect.y+455))
        surface.blit(mute,(self.rect.x+text_surface16.get_width()+20,self.rect.y+485))
        surface.blit(info_button,(self.rect.x+text_surface17.get_width()+20,self.rect.y+515))

        surface.blit(ok_button,(0,WIDTH-50))
        pygame.display.flip()
    def no_exit(self):
        '''if the tick is clicked, the help screen is exited'''
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse = pygame.mouse.get_pos()
                if 0<mouse[0]<60 and WIDTH-50<mouse[1]<WIDTH-10:
                    return False
        return True






