import pygame
import menu
import player
import game
'''code that runs the game'''
pygame.init()
pygame.display.set_caption("Angry Birds")
p1,p2,level_no = menu.menu()
game.game(p1,p2,level_no)
pygame.quit()